package com.urbanshield.app.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.urbanshield.app.data.RiskZoneRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Los geofences que registra Android se borran cuando el dispositivo se reinicia.
 * Este receptor los vuelve a registrar automáticamente al encender el teléfono,
 * para que las alertas sigan funcionando sin que el usuario tenga que abrir la app.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val zones = RiskZoneRepository().getRiskZones()
                    GeofenceHelper(context).registerGeofences(zones)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
