package com.urbanshield.app.ui

/**
 * Implementada por HomeActivity. Permite que un fragment (por ejemplo, una
 * tarjeta de acceso rápido en HomeFragment) cambie de pestaña sin necesitar un
 * cast directo a HomeActivity ni conocer los detalles de FragmentManager.
 */
interface TabNavigator {
    fun navigateToTab(itemId: Int)
}
