package com.urbanshield.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.urbanshield.app.R
import com.urbanshield.app.data.RiskLevel
import com.urbanshield.app.data.RiskZone
import com.urbanshield.app.databinding.ItemZoneBinding

/** Lista completa de zonas de riesgo (pestaña "Zonas"), con un chip de color por nivel. */
class ZonesAdapter(private var items: List<RiskZone>) :
    RecyclerView.Adapter<ZonesAdapter.ZoneViewHolder>() {

    fun submitList(newItems: List<RiskZone>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ZoneViewHolder {
        val binding = ItemZoneBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ZoneViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ZoneViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    class ZoneViewHolder(private val binding: ItemZoneBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(zone: RiskZone) {
            val context = binding.root.context
            binding.textZoneName.text = zone.name

            val (label, colorRes) = when (zone.riskLevel) {
                RiskLevel.ALTO -> context.getString(R.string.zone_risk_alto) to R.color.risk_high
                RiskLevel.MEDIO -> context.getString(R.string.zone_risk_medio) to R.color.risk_medium
                RiskLevel.BAJO -> context.getString(R.string.zone_risk_bajo) to R.color.risk_low
            }
            binding.textZoneRisk.text = zone.riskLevel.name
            binding.textZoneRisk.contentDescription = label
            // .mutate() es indispensable: sin él, el Drawable de fondo se comparte entre
            // TODOS los ítems del RecyclerView y cambiar su color afectaría a todos a la vez.
            binding.textZoneRisk.background.mutate().setTint(context.getColor(colorRes))
        }
    }
}
