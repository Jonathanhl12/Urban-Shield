package com.urbanshield.app.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofenceStatusCodes
import com.google.android.gms.location.GeofencingEvent
import com.urbanshield.app.data.RiskZoneRepository
import com.urbanshield.app.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Se activa automáticamente cuando el sistema operativo detecta que el usuario
 * entró o permaneció dentro de una zona de riesgo registrada.
 * No requiere que la app esté abierta.
 */
class GeofenceBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent) ?: return

        if (geofencingEvent.hasError()) {
            val errorMessage = GeofenceStatusCodes.getStatusCodeString(geofencingEvent.errorCode)
            android.util.Log.e("UrbanShield", "Error de geofencing: $errorMessage")
            return
        }

        val transition = geofencingEvent.geofenceTransition
        val triggeringGeofences = geofencingEvent.triggeringGeofences ?: return
        val isEntering = transition == Geofence.GEOFENCE_TRANSITION_ENTER

        // goAsync() permite hacer trabajo async (consultar Firestore) dentro de un BroadcastReceiver
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = RiskZoneRepository()
                val zones = repository.getRiskZones()

                triggeringGeofences.forEach { geofence ->
                    val zone = zones.find { it.id == geofence.requestId }
                    if (zone != null) {
                        NotificationHelper.showRiskAlert(
                            context, zone.name, zone.riskLevel, isEntering, zone.lat, zone.lng
                        )
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
