package com.urbanshield.app.data

/**
 * Representa una zona de riesgo dentro de UrbanShield.
 *
 * @param id Identificador único (se usa también como ID del Geofence).
 * @param name Nombre visible de la zona (ej. "Av. Central y 5ta calle").
 * @param lat Latitud del centro de la zona.
 * @param lng Longitud del centro de la zona.
 * @param radiusMeters Radio de la zona en metros (qué tan grande es el círculo de alerta).
 * @param riskLevel Nivel de riesgo: ALTO, MEDIO o BAJO. Se usa para el color en el mapa
 *                  y para redactar el texto de la notificación.
 */
data class RiskZone(
    val id: String = "",
    val name: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val radiusMeters: Float = 150f,
    val riskLevel: RiskLevel = RiskLevel.MEDIO
) {
    // Constructor vacío requerido por Firestore para deserializar documentos
    constructor() : this("", "", 0.0, 0.0, 150f, RiskLevel.MEDIO)
}

enum class RiskLevel {
    ALTO, MEDIO, BAJO
}
