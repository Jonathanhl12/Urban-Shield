package com.urbanshield.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.urbanshield.app.databinding.ActivityMainBinding

/**
 * Paso técnico entre WelcomeActivity y HomeActivity: pide los permisos de
 * ubicación (y notificaciones en Android 13+) sin mostrar una pantalla de
 * "Permisos" dedicada — solo un indicador de carga. Si el usuario rechaza el
 * permiso de ubicación, se muestra un mensaje y un botón para reintentar.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val fineLocationGranted = results[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        if (fineLocationGranted) {
            requestBackgroundLocationIfNeeded()
        } else {
            showRetry()
        }
    }

    private val backgroundLocationLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) {
        openHome()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonStart.setOnClickListener { checkAndRequestPermissions() }
        checkAndRequestPermissions()
    }

    private fun checkAndRequestPermissions() {
        showLoading()

        val fineLocationGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val permissionsToRequest = mutableListOf<String>()
        if (!fineLocationGranted) permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!notifGranted) permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissionsToRequest.isEmpty()) {
            requestBackgroundLocationIfNeeded()
        } else {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    private fun requestBackgroundLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val backgroundGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (!backgroundGranted) {
                backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                return
            }
        }
        openHome()
    }

    private fun showLoading() {
        binding.progressPermissions.visibility = View.VISIBLE
        binding.textStatus.visibility = View.GONE
        binding.buttonStart.visibility = View.GONE
    }

    private fun showRetry() {
        binding.progressPermissions.visibility = View.GONE
        binding.textStatus.text = getString(R.string.permission_location_required)
        binding.textStatus.visibility = View.VISIBLE
        binding.buttonStart.visibility = View.VISIBLE
    }

    private fun openHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
