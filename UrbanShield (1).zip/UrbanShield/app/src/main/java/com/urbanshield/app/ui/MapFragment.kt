package com.urbanshield.app.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Circle
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.urbanshield.app.R
import com.urbanshield.app.data.RiskLevel
import com.urbanshield.app.data.RiskZone
import com.urbanshield.app.data.RiskZoneRepository
import com.urbanshield.app.databinding.FragmentMapBinding
import com.urbanshield.app.geofence.GeofenceHelper
import kotlinx.coroutines.launch

/**
 * Pestaña "Mapa": el núcleo funcional de la app. Muestra el mapa de Google Maps
 * con la ubicación del usuario y las zonas de riesgo, registra los geofences
 * correspondientes, y permite filtrar las zonas visibles por nombre desde la
 * barra de búsqueda superior.
 */
class MapFragment : Fragment(), OnMapReadyCallback {

    private var _binding: FragmentMapBinding? = null
    private val binding get() = _binding!!

    private lateinit var map: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var geofenceHelper: GeofenceHelper
    private val repository = RiskZoneRepository()
    private var zonesLoaded = false

    /** Guarda cada zona junto con su círculo y su marcador, para poder mostrarlos u
     * ocultarlos cuando el usuario escribe en la barra de búsqueda. */
    private data class ZoneOverlay(val zone: RiskZone, val circle: Circle, val marker: Marker)
    private val zoneOverlays = mutableListOf<ZoneOverlay>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMapBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
        geofenceHelper = GeofenceHelper(requireContext())

        // Un <fragment> anidado dentro del layout de OTRO fragment se debe buscar
        // con childFragmentManager, no con el supportFragmentManager de la Activity.
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.fabRecenter.setOnClickListener { recenterOnUser() }
        setupSearch()
    }

    private fun setupSearch() {
        binding.editSearchZone.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterZones(s?.toString().orEmpty())
            }
        })
    }

    private fun filterZones(query: String) {
        val normalizedQuery = query.trim()
        zoneOverlays.forEach { overlay ->
            val visible = normalizedQuery.isEmpty() ||
                overlay.zone.name.contains(normalizedQuery, ignoreCase = true)
            overlay.circle.isVisible = visible
            overlay.marker.isVisible = visible
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        enableMyLocationIfPermitted()
        if (!zonesLoaded) {
            loadRiskZones()
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableMyLocationIfPermitted() {
        map.isMyLocationEnabled = true
        map.uiSettings.isMyLocationButtonEnabled = false // usamos nuestro propio FAB

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val userLatLng = LatLng(location.latitude, location.longitude)
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 12f))
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun recenterOnUser() {
        if (!::map.isInitialized) return
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val userLatLng = LatLng(location.latitude, location.longitude)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 14f))
            }
        }
    }

    private fun loadRiskZones() {
        viewLifecycleOwner.lifecycleScope.launch {
            val zones = repository.getRiskZones()
            if (_binding == null) return@launch
            zonesLoaded = true
            drawZonesOnMap(zones)
            registerGeofencesForZones(zones)
        }
    }

    private fun drawZonesOnMap(zones: List<RiskZone>) {
        zones.forEach { zone ->
            val position = LatLng(zone.lat, zone.lng)
            val color = colorForRiskLevel(zone.riskLevel)

            val circle = map.addCircle(
                CircleOptions()
                    .center(position)
                    .radius(zone.radiusMeters.toDouble())
                    .strokeWidth(2f)
                    .strokeColor(color)
                    .fillColor(withAlpha(color, 60))
            )

            val marker = map.addMarker(
                MarkerOptions()
                    .position(position)
                    .title(zone.name)
                    .snippet("Riesgo: ${zone.riskLevel}")
                    .icon(BitmapDescriptorFactory.defaultMarker(hueForRiskLevel(zone.riskLevel)))
            )

            if (marker != null) {
                zoneOverlays.add(ZoneOverlay(zone, circle, marker))
            }
        }
    }

    private fun registerGeofencesForZones(zones: List<RiskZone>) {
        geofenceHelper.registerGeofences(
            zones,
            onSuccess = {
                if (isAdded) {
                    Toast.makeText(requireContext(), getString(R.string.geofences_registered), Toast.LENGTH_SHORT).show()
                }
            },
            onFailure = { e ->
                android.util.Log.e("UrbanShield", "No se pudieron registrar geofences: ${e.message}")
            }
        )
    }

    // Semántica de color según la guía de estilo: rojo=alto, naranja=medio, amarillo=bajo
    private fun colorForRiskLevel(level: RiskLevel): Int = when (level) {
        RiskLevel.ALTO -> android.graphics.Color.RED
        RiskLevel.MEDIO -> android.graphics.Color.rgb(255, 165, 0)
        RiskLevel.BAJO -> android.graphics.Color.rgb(251, 192, 45) // #FBC02D, amarillo
    }

    private fun hueForRiskLevel(level: RiskLevel): Float = when (level) {
        RiskLevel.ALTO -> BitmapDescriptorFactory.HUE_RED
        RiskLevel.MEDIO -> BitmapDescriptorFactory.HUE_ORANGE
        RiskLevel.BAJO -> BitmapDescriptorFactory.HUE_YELLOW
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        return android.graphics.Color.argb(
            alpha,
            android.graphics.Color.red(color),
            android.graphics.Color.green(color),
            android.graphics.Color.blue(color)
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        zoneOverlays.clear()
        _binding = null
    }
}
