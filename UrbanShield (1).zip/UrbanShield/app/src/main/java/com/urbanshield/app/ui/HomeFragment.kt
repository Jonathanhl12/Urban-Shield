package com.urbanshield.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.urbanshield.app.R
import com.urbanshield.app.data.AlertHistoryStore
import com.urbanshield.app.data.RiskZoneRepository
import com.urbanshield.app.databinding.FragmentHomeBinding
import kotlinx.coroutines.launch

/**
 * Pestaña "Inicio": saluda al usuario, muestra estadísticas rápidas (zonas
 * monitoreadas y alertas recibidas) y da acceso directo a las otras pestañas
 * mediante tarjetas (patrón "Cards" de Material Design).
 */
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val repository = RiskZoneRepository()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val currentUser = FirebaseAuth.getInstance().currentUser
        binding.textGreeting.text = if (currentUser?.email != null) {
            getString(R.string.home_greeting_user, currentUser.email)
        } else {
            getString(R.string.home_greeting_guest)
        }

        binding.cardGoToMap.setOnClickListener { navigator()?.navigateToTab(R.id.nav_map) }
        binding.cardGoToAlerts.setOnClickListener { navigator()?.navigateToTab(R.id.nav_alerts) }
        binding.cardGoToZones.setOnClickListener { navigator()?.navigateToTab(R.id.nav_zones) }

        loadStats()
    }

    override fun onResume() {
        super.onResume()
        binding.textAlertsCount.text = AlertHistoryStore.readAll(requireContext()).size.toString()
    }

    private fun loadStats() {
        viewLifecycleOwner.lifecycleScope.launch {
            val zones = repository.getRiskZones()
            if (_binding != null) {
                binding.textZonesCount.text = zones.size.toString()
            }
        }
        binding.textAlertsCount.text = AlertHistoryStore.readAll(requireContext()).size.toString()
    }

    private fun navigator(): TabNavigator? = activity as? TabNavigator

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
