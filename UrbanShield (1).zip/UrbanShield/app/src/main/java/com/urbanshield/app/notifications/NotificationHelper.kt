package com.urbanshield.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.urbanshield.app.R
import com.urbanshield.app.data.AlertHistoryStore
import com.urbanshield.app.data.AlertRecord
import com.urbanshield.app.data.RiskLevel

/**
 * Centraliza la creación del canal de notificaciones y el envío de alertas.
 * Mantener esta lógica en un solo lugar facilita cambiar el texto o el
 * comportamiento de las alertas sin tocar el resto de la app.
 */
object NotificationHelper {

    const val CHANNEL_ID = "urbanshield_alerts"
    private const val CHANNEL_NAME = "Alertas de seguridad"
    private const val CHANNEL_DESCRIPTION =
        "Notificaciones cuando te acercas o entras a una zona de riesgo"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESCRIPTION
                enableVibration(true)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * Muestra una alerta preventiva y la guarda en el historial local. El texto
     * cambia según el nivel de riesgo y si el usuario está "entrando" a la zona
     * o solo "cerca" de ella. Se reciben lat/lng de la zona para poder calcular
     * distancia real después, en el filtro "Cercanas" de la pestaña Alertas.
     */
    fun showRiskAlert(
        context: Context,
        zoneName: String,
        riskLevel: RiskLevel,
        isEntering: Boolean,
        lat: Double = 0.0,
        lng: Double = 0.0
    ) {
        val title = if (isEntering) {
            "Entraste a una zona de riesgo"
        } else {
            "Zona de riesgo cercana"
        }

        val riskText = when (riskLevel) {
            RiskLevel.ALTO -> "Nivel de riesgo ALTO"
            RiskLevel.MEDIO -> "Nivel de riesgo MEDIO"
            RiskLevel.BAJO -> "Nivel de riesgo BAJO"
        }

        val message = "$zoneName · $riskText. Mantente alerta y evita distraerte."

        // Se guarda en el historial local independientemente de si el permiso de
        // notificación está concedido, para que la pestaña "Alertas" siempre refleje
        // las zonas de riesgo que el usuario realmente cruzó.
        AlertHistoryStore.addAlert(
            context,
            AlertRecord(
                zoneName = zoneName,
                riskLevel = riskLevel,
                isEntering = isEntering,
                timestampMillis = System.currentTimeMillis(),
                lat = lat,
                lng = lng
            )
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        // En Android 13+ se debe verificar el permiso POST_NOTIFICATIONS antes de notificar
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            // notificationId basado en el nombre de la zona para no duplicar alertas repetidas
            val notificationId = zoneName.hashCode()
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        }
    }
}
