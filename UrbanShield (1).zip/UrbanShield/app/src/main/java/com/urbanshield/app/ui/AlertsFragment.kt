package com.urbanshield.app.ui

import android.annotation.SuppressLint
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.urbanshield.app.R
import com.urbanshield.app.data.AlertHistoryStore
import com.urbanshield.app.data.AlertRecord
import com.urbanshield.app.databinding.FragmentAlertsBinding

/**
 * Pestaña "Alertas": historial local de las notificaciones de proximidad recibidas,
 * con 3 filtros (igual que el wireframe): Todas, Cercanas (por distancia real a tu
 * ubicación actual) y Guardadas (alertas marcadas con el ícono de bookmark).
 */
class AlertsFragment : Fragment() {

    private enum class Filter { ALL, NEARBY, SAVED }

    private var _binding: FragmentAlertsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: AlertsAdapter
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var activeFilter = Filter.ALL
    private var lastKnownLocation: Location? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlertsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        adapter = AlertsAdapter(emptyList()) { record ->
            AlertHistoryStore.toggleSaved(requireContext(), record.timestampMillis)
            refresh()
        }
        binding.recyclerAlerts.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerAlerts.adapter = adapter

        binding.chipAll.setOnClickListener { selectFilter(Filter.ALL) }
        binding.chipNearby.setOnClickListener { selectFilter(Filter.NEARBY) }
        binding.chipSaved.setOnClickListener { selectFilter(Filter.SAVED) }
    }

    override fun onResume() {
        super.onResume()
        // Si ProfileFragment pidió abrir directamente en "Guardadas", lo aplicamos una vez.
        if (pendingFilterRequest != null) {
            activeFilter = pendingFilterRequest!!
            pendingFilterRequest = null
            updateChipStyles()
        }
        refreshLocationThenList()
    }

    private fun selectFilter(filter: Filter) {
        activeFilter = filter
        updateChipStyles()
        refresh()
    }

    private fun updateChipStyles() {
        setChipState(binding.chipAll, activeFilter == Filter.ALL)
        setChipState(binding.chipNearby, activeFilter == Filter.NEARBY)
        setChipState(binding.chipSaved, activeFilter == Filter.SAVED)
    }

    private fun setChipState(chip: android.widget.TextView, selected: Boolean) {
        chip.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected)
        chip.setTextColor(
            if (selected) requireContext().getColor(R.color.background)
            else requireContext().getColor(R.color.text_primary)
        )
    }

    @SuppressLint("MissingPermission")
    private fun refreshLocationThenList() {
        if (activeFilter == Filter.NEARBY) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                lastKnownLocation = location
                refresh()
            }.addOnFailureListener {
                refresh()
            }
        } else {
            refresh()
        }
    }

    private fun refresh() {
        val allAlerts = AlertHistoryStore.readAll(requireContext())
        val filtered = when (activeFilter) {
            Filter.ALL -> allAlerts
            Filter.SAVED -> allAlerts.filter { it.isSaved }
            Filter.NEARBY -> filterByDistance(allAlerts)
        }

        adapter.submitList(filtered)
        val isEmpty = filtered.isEmpty()
        binding.recyclerAlerts.visibility = if (isEmpty) View.GONE else View.VISIBLE
        binding.layoutEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE

        if (isEmpty) {
            binding.textEmptyDesc.text = when (activeFilter) {
                Filter.SAVED -> getString(R.string.alerts_empty_saved)
                Filter.NEARBY -> getString(R.string.alerts_empty_nearby)
                Filter.ALL -> getString(R.string.alerts_empty_desc)
            }
        }
    }

    /** Filtra alertas dentro de un radio de 5 km de la ubicación actual del usuario. */
    private fun filterByDistance(alerts: List<AlertRecord>): List<AlertRecord> {
        val current = lastKnownLocation ?: return emptyList()
        return alerts.filter { record ->
            if (record.lat == 0.0 && record.lng == 0.0) return@filter false
            val results = FloatArray(1)
            Location.distanceBetween(current.latitude, current.longitude, record.lat, record.lng, results)
            results[0] <= NEARBY_RADIUS_METERS
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val NEARBY_RADIUS_METERS = 5000f

        /** Mecanismo simple para que ProfileFragment pida abrir Alertas ya filtrado en
         * "Guardadas", sin acoplar ambos fragments directamente. */
        private var pendingFilterRequest: Filter? = null

        fun requestSavedFilterOnNextOpen() {
            pendingFilterRequest = Filter.SAVED
        }
    }
}
