package com.urbanshield.app.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Fuente única de verdad para las zonas de riesgo.
 *
 * Intenta leer la colección "risk_zones" de Firestore. Si Firestore aún no tiene
 * datos (proyecto nuevo) o no hay conexión, regresa una lista local de zonas reales
 * en la Ciudad de México y el Estado de México (ver sampleZones()), para que la app
 * sea útil desde el primer momento sin depender de que ya se haya cargado Firestore.
 *
 * Para cargar tus propias zonas en Firestore (y que tengan prioridad sobre el
 * respaldo local), sube documentos con esta forma:
 * colección: risk_zones
 * documento: { name: "...", lat: 19.xxx, lng: -99.xxx, radiusMeters: 200, riskLevel: "ALTO" }
 */
class RiskZoneRepository {

    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("risk_zones")

    suspend fun getRiskZones(): List<RiskZone> {
        return try {
            val snapshot = collection.get().await()
            if (snapshot.isEmpty) {
                sampleZones()
            } else {
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(RiskZone::class.java)?.copy(id = doc.id)
                }
            }
        } catch (e: Exception) {
            // Sin internet o sin configurar Firebase todavía: usamos datos de ejemplo
            sampleZones()
        }
    }

    /** Sube una nueva zona de riesgo a Firestore (para reportes ciudadanos futuros). */
    suspend fun addRiskZone(zone: RiskZone) {
        collection.add(zone).await()
    }

    /**
     * Zonas de riesgo en la Ciudad de México y el Estado de México (Zona Metropolitana
     * del Valle de México), usadas como respaldo local cuando Firestore aún no tiene
     * datos cargados o no hay conexión a internet.
     *
     * Basadas en fuentes públicas reales sobre incidencia e inseguridad:
     *  - INEGI, Encuesta Nacional de Seguridad Pública Urbana (ENSU), 4º trimestre de 2025
     *    y 1º trimestre de 2026 (percepción de inseguridad por alcaldía/municipio).
     *  - Fiscalía General de Justicia de la Ciudad de México (FGJ), Índice de Seguridad
     *    por alcaldía, con base en carpetas de investigación 2023 (datos abiertos CDMX).
     *  - Secretariado Ejecutivo del Sistema Nacional de Seguridad Pública (SESNSP) y
     *    Fiscalía General de Justicia del Estado de México (FGJEM), reportes 2025-2026.
     *
     * Las coordenadas marcan el centro aproximado de cada alcaldía/municipio o colonia
     * (no una dirección exacta de un incidente); antes de un uso real se recomienda
     * sustituir estos puntos por datos geolocalizados oficiales y mantenerlos actualizados.
     */
    private fun sampleZones(): List<RiskZone> = listOf(
        // ---------- Ciudad de México ----------
        RiskZone("cdmx_tepito", "Tepito, Cuauhtémoc (CDMX)", 19.4453, -99.1332, 400f, RiskLevel.ALTO),
        RiskZone("cdmx_centro_historico", "Centro Histórico, Cuauhtémoc (CDMX)", 19.4326, -99.1332, 600f, RiskLevel.ALTO),
        RiskZone("cdmx_la_merced", "La Merced, Venustiano Carranza (CDMX)", 19.4249, -99.1247, 400f, RiskLevel.ALTO),
        RiskZone("cdmx_doctores", "Doctores, Cuauhtémoc (CDMX)", 19.4204, -99.1489, 450f, RiskLevel.MEDIO),
        RiskZone("cdmx_santa_martha", "Santa Martha Acatitla, Iztapalapa (CDMX)", 19.3570, -98.9880, 500f, RiskLevel.MEDIO),
        RiskZone("cdmx_gam", "Gustavo A. Madero (CDMX)", 19.4840, -99.1140, 800f, RiskLevel.MEDIO),
        RiskZone("cdmx_xochimilco", "Xochimilco, centro (CDMX)", 19.2647, -99.1031, 700f, RiskLevel.MEDIO),
        RiskZone("cdmx_tlahuac", "Tláhuac, centro (CDMX)", 19.2867, -99.0056, 700f, RiskLevel.MEDIO),

        // ---------- Estado de México (Zona Metropolitana del Valle de México) ----------
        RiskZone("edomex_ecatepec", "Ecatepec de Morelos, centro (Edomex)", 19.6018, -99.0505, 1200f, RiskLevel.ALTO),
        RiskZone("edomex_chimalhuacan", "Chimalhuacán, centro (Edomex)", 19.4200, -98.9500, 1000f, RiskLevel.ALTO),
        RiskZone("edomex_naucalpan", "Naucalpan de Juárez, centro (Edomex)", 19.4776, -99.2394, 900f, RiskLevel.ALTO),
        RiskZone("edomex_cuautitlan_izcalli", "Cuautitlán Izcalli, centro (Edomex)", 19.6499, -99.2179, 800f, RiskLevel.MEDIO),
        RiskZone("edomex_tlalnepantla", "Tlalnepantla de Baz, centro (Edomex)", 19.5378, -99.1955, 900f, RiskLevel.MEDIO),
        RiskZone("edomex_neza", "Ciudad Nezahualcóyotl, centro (Edomex)", 19.4003, -99.0148, 1000f, RiskLevel.MEDIO),
        RiskZone("edomex_tultitlan", "Tultitlán, centro (Edomex)", 19.6461, -99.1592, 800f, RiskLevel.MEDIO),
        RiskZone("edomex_toluca", "Toluca, Centro Histórico (Edomex)", 19.2926, -99.6568, 700f, RiskLevel.MEDIO)
    )
}
