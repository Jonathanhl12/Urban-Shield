package com.urbanshield.app.geofence

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.urbanshield.app.data.RiskZone

/**
 * Encapsula toda la lógica para registrar las zonas de riesgo como "geofences"
 * del sistema. Una vez registradas, Android avisa a GeofenceBroadcastReceiver
 * automáticamente cuando el usuario entra o sale de una zona, incluso si la
 * app está cerrada.
 */
class GeofenceHelper(private val context: Context) {

    private val geofencingClient: GeofencingClient = LocationServices.getGeofencingClient(context)

    private val geofencePendingIntent: PendingIntent by lazy {
        val intent = Intent(context, GeofenceBroadcastReceiver::class.java)
        intent.action = ACTION_GEOFENCE_EVENT
        PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    /** Convierte una RiskZone (nuestro modelo) en un Geofence (API de Google) */
    private fun buildGeofence(zone: RiskZone): Geofence {
        return Geofence.Builder()
            .setRequestId(zone.id)
            .setCircularRegion(zone.lat, zone.lng, zone.radiusMeters)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_DWELL)
            .setLoiteringDelay(30_000) // 30s dentro de la zona para disparar DWELL
            .build()
    }

    /**
     * Registra todas las zonas recibidas como geofences activos.
     * Debe llamarse solo después de tener permisos de ubicación (fino + segundo plano).
     */
    @SuppressLint("MissingPermission")
    fun registerGeofences(zones: List<RiskZone>, onSuccess: () -> Unit = {}, onFailure: (Exception) -> Unit = {}) {
        if (zones.isEmpty()) return

        val geofenceList = zones.map { buildGeofence(it) }
        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(geofenceList)
            .build()

        geofencingClient.addGeofences(request, geofencePendingIntent)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e) }
    }

    fun removeAllGeofences() {
        geofencingClient.removeGeofences(geofencePendingIntent)
    }

    companion object {
        const val ACTION_GEOFENCE_EVENT = "com.urbanshield.app.ACTION_GEOFENCE_EVENT"
    }
}
