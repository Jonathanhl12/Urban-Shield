package com.urbanshield.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.urbanshield.app.databinding.ActivityWelcomeBinding

/**
 * Pantalla de inicio de la app (launcher). Ofrece dos caminos:
 *  1) Iniciar sesión / crear cuenta con Firebase Authentication (correo y contraseña).
 *  2) Presionar "Continuar" para entrar como invitado, sin cuenta.
 *
 * En ambos casos se termina en MainActivity, que es quien ya se encarga de
 * pedir los permisos de ubicación y abrir la app.
 */
class WelcomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding
    private lateinit var auth: FirebaseAuth
    private var isRegisterMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()

        // Si ya había una sesión activa, no mostramos el formulario: pasamos directo a la app.
        if (auth.currentUser != null) {
            goToMain()
            return
        }

        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonPrimaryAction.setOnClickListener { onPrimaryActionClicked() }
        binding.textToggleMode.setOnClickListener { toggleMode() }
        binding.buttonContinueGuest.setOnClickListener { goToMain() }
    }

    private fun onPrimaryActionClicked() {
        val email = binding.editEmail.text?.toString()?.trim().orEmpty()
        val password = binding.editPassword.text?.toString()?.trim().orEmpty()

        if (email.isEmpty() || password.isEmpty()) {
            binding.textError.text = getString(R.string.error_empty_fields)
            binding.textError.visibility = View.VISIBLE
            return
        }
        if (password.length < 6) {
            binding.textError.text = getString(R.string.error_password_length)
            binding.textError.visibility = View.VISIBLE
            return
        }

        setLoading(true)
        if (isRegisterMode) {
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    setLoading(false)
                    if (task.isSuccessful) {
                        goToMain()
                    } else {
                        showError(task.exception?.message)
                    }
                }
        } else {
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    setLoading(false)
                    if (task.isSuccessful) {
                        goToMain()
                    } else {
                        showError(task.exception?.message)
                    }
                }
        }
    }

    private fun toggleMode() {
        isRegisterMode = !isRegisterMode
        binding.textError.visibility = View.GONE
        if (isRegisterMode) {
            binding.buttonPrimaryAction.text = getString(R.string.button_create_account)
            binding.textToggleMode.text = getString(R.string.toggle_to_login)
            binding.textTitle.text = getString(R.string.welcome_title_register)
        } else {
            binding.buttonPrimaryAction.text = getString(R.string.button_login)
            binding.textToggleMode.text = getString(R.string.toggle_to_register)
            binding.textTitle.text = getString(R.string.welcome_title_login)
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.buttonPrimaryAction.isEnabled = !loading
        binding.buttonContinueGuest.isEnabled = !loading
    }

    private fun showError(message: String?) {
        binding.textError.text = message ?: getString(R.string.error_generic_auth)
        binding.textError.visibility = View.VISIBLE
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
