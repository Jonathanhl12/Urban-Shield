package com.urbanshield.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Guarda un historial local de las alertas que el usuario ha recibido, para
 * mostrarlo en la pestaña "Alertas". No usa una base de datos completa (Room)
 * porque el volumen de datos es pequeño y de un solo dispositivo; con
 * SharedPreferences + un arreglo JSON es suficiente y evita una dependencia
 * adicional.
 */
object AlertHistoryStore {

    private const val PREFS_NAME = "urbanshield_alert_history"
    private const val KEY_ALERTS = "alerts_json"
    private const val MAX_STORED_ALERTS = 100

    fun addAlert(context: Context, record: AlertRecord) {
        val current = readAll(context).toMutableList()
        current.add(0, record) // más reciente primero
        saveAll(context, current.take(MAX_STORED_ALERTS))
    }

    /** Alterna el estado "guardada" (bookmark) de una alerta, identificada por su
     * marca de tiempo (suficientemente única para este caso de uso). */
    fun toggleSaved(context: Context, timestampMillis: Long) {
        val current = readAll(context).map { record ->
            if (record.timestampMillis == timestampMillis) {
                record.copy(isSaved = !record.isSaved)
            } else {
                record
            }
        }
        saveAll(context, current)
    }

    fun readAll(context: Context): List<AlertRecord> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_ALERTS, null) ?: return emptyList()
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                AlertRecord(
                    zoneName = obj.getString("zoneName"),
                    riskLevel = RiskLevel.valueOf(obj.getString("riskLevel")),
                    isEntering = obj.getBoolean("isEntering"),
                    timestampMillis = obj.getLong("timestampMillis"),
                    lat = obj.optDouble("lat", 0.0),
                    lng = obj.optDouble("lng", 0.0),
                    isSaved = obj.optBoolean("isSaved", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun saveAll(context: Context, records: List<AlertRecord>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        records.forEach { r ->
            val obj = JSONObject()
            obj.put("zoneName", r.zoneName)
            obj.put("riskLevel", r.riskLevel.name)
            obj.put("isEntering", r.isEntering)
            obj.put("timestampMillis", r.timestampMillis)
            obj.put("lat", r.lat)
            obj.put("lng", r.lng)
            obj.put("isSaved", r.isSaved)
            array.put(obj)
        }
        prefs.edit().putString(KEY_ALERTS, array.toString()).apply()
    }
}
