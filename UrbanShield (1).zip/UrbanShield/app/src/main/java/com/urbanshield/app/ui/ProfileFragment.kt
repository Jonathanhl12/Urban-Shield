package com.urbanshield.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.urbanshield.app.R
import com.urbanshield.app.WelcomeActivity
import com.urbanshield.app.databinding.FragmentProfileBinding

/**
 * Pestaña "Perfil": muestra el estado de la sesión (correo o modo invitado),
 * un menú de cuenta, el interruptor de alertas de proximidad y la opción de
 * cerrar sesión.
 *
 * Nota: "Información personal", "Mis reportes", "Ayuda y soporte" y "Editar
 * perfil" todavía no tienen una pantalla propia — por ahora muestran un aviso.
 * "Alertas guardadas" sí es funcional: navega a la pestaña Alertas ya
 * filtrada en "Guardadas".
 */
class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        binding.switchAlerts.isChecked = prefs.getBoolean(KEY_ALERTS_ENABLED, true)
        binding.switchAlerts.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(KEY_ALERTS_ENABLED, isChecked).apply()
        }

        val currentUser = auth.currentUser
        if (currentUser != null) {
            val displayName = currentUser.displayName?.takeIf { it.isNotBlank() }
                ?: currentUser.email?.substringBefore("@")
                ?: getString(R.string.home_greeting_guest)
            binding.textDisplayName.text = displayName
            binding.textAccountStatus.text = currentUser.email.orEmpty()
            binding.buttonLogout.visibility = View.VISIBLE
            binding.buttonLogout.setOnClickListener { logout() }
        } else {
            binding.textDisplayName.text = getString(R.string.home_greeting_guest)
            binding.textAccountStatus.text = getString(R.string.guest_mode_label)
        }

        val comingSoon = { showComingSoon() }
        binding.buttonEditPhoto.setOnClickListener { comingSoon() }
        binding.buttonEditProfile.setOnClickListener { comingSoon() }
        binding.menuPersonalInfo.setOnClickListener { comingSoon() }
        binding.menuMyReports.setOnClickListener { comingSoon() }
        binding.menuHelp.setOnClickListener { comingSoon() }

        binding.menuSavedAlerts.setOnClickListener {
            AlertsFragment.requestSavedFilterOnNextOpen()
            (activity as? TabNavigator)?.navigateToTab(R.id.nav_alerts)
        }
    }

    private fun showComingSoon() {
        Toast.makeText(requireContext(), getString(R.string.feature_coming_soon), Toast.LENGTH_SHORT).show()
    }

    private fun logout() {
        auth.signOut()
        val intent = Intent(requireContext(), WelcomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val PREFS_NAME = "urbanshield_prefs"
        const val KEY_ALERTS_ENABLED = "alerts_enabled"
    }
}
