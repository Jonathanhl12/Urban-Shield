package com.urbanshield.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.urbanshield.app.R
import com.urbanshield.app.data.AlertRecord
import com.urbanshield.app.data.RiskLevel
import com.urbanshield.app.databinding.ItemAlertBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Muestra el historial local de alertas (pestaña "Alertas"), más recientes primero. */
class AlertsAdapter(
    private var items: List<AlertRecord>,
    private val onToggleSaved: (AlertRecord) -> Unit
) : RecyclerView.Adapter<AlertsAdapter.AlertViewHolder>() {

    private val dateFormat = SimpleDateFormat("d MMM yyyy, h:mm a", Locale("es", "MX"))

    fun submitList(newItems: List<AlertRecord>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlertViewHolder {
        val binding = ItemAlertBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlertViewHolder(binding, onToggleSaved)
    }

    override fun onBindViewHolder(holder: AlertViewHolder, position: Int) {
        holder.bind(items[position], dateFormat)
    }

    override fun getItemCount(): Int = items.size

    class AlertViewHolder(
        private val binding: ItemAlertBinding,
        private val onToggleSaved: (AlertRecord) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(record: AlertRecord, dateFormat: SimpleDateFormat) {
            val context = binding.root.context

            val typeLabel = if (record.isEntering) {
                context.getString(R.string.alert_entering_label)
            } else {
                context.getString(R.string.alert_nearby_label)
            }
            binding.textAlertType.text = typeLabel
            binding.textAlertZoneName.text = record.zoneName

            val riskLabel = when (record.riskLevel) {
                RiskLevel.ALTO -> context.getString(R.string.zone_risk_alto)
                RiskLevel.MEDIO -> context.getString(R.string.zone_risk_medio)
                RiskLevel.BAJO -> context.getString(R.string.zone_risk_bajo)
            }
            binding.textAlertTime.text = "$riskLabel · ${dateFormat.format(Date(record.timestampMillis))}"

            val color = when (record.riskLevel) {
                RiskLevel.ALTO -> R.color.risk_high
                RiskLevel.MEDIO -> R.color.risk_medium
                RiskLevel.BAJO -> R.color.risk_low
            }
            binding.viewRiskIndicator.setBackgroundColor(context.getColor(color))

            val bookmarkIcon = if (record.isSaved) R.drawable.ic_bookmark_filled else R.drawable.ic_bookmark_border
            val bookmarkTint = if (record.isSaved) R.color.primary else R.color.nav_unselected
            binding.buttonToggleSaved.setImageResource(bookmarkIcon)
            binding.buttonToggleSaved.imageTintList =
                android.content.res.ColorStateList.valueOf(context.getColor(bookmarkTint))
            binding.buttonToggleSaved.setOnClickListener { onToggleSaved(record) }
        }
    }
}
