package com.urbanshield.app

import android.app.Application
import com.urbanshield.app.notifications.NotificationHelper

/**
 * Clase Application: se ejecuta una sola vez cuando arranca la app.
 * Aquí creamos el canal de notificaciones para que esté listo antes
 * de que se dispare cualquier alerta de geofencing.
 */
class UrbanShieldApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
    }
}
