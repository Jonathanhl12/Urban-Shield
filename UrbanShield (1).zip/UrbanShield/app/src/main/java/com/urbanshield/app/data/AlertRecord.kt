package com.urbanshield.app.data

/**
 * Representa una alerta que ya se le mostró al usuario (una entrada del historial
 * que se ve en la pestaña "Alertas"). Se genera cada vez que NotificationHelper
 * dispara una notificación de proximidad.
 *
 * @param lat Latitud de la zona (se guarda para poder calcular distancia real en
 *            el filtro "Cercanas" de la pestaña Alertas).
 * @param lng Longitud de la zona.
 * @param isSaved Si el usuario marcó esta alerta con el ícono de guardado (bookmark).
 */
data class AlertRecord(
    val zoneName: String,
    val riskLevel: RiskLevel,
    val isEntering: Boolean,
    val timestampMillis: Long,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val isSaved: Boolean = false
)
