package com.urbanshield.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.urbanshield.app.databinding.ActivityHomeBinding
import com.urbanshield.app.ui.AlertsFragment
import com.urbanshield.app.ui.HomeFragment
import com.urbanshield.app.ui.MapFragment
import com.urbanshield.app.ui.ProfileFragment
import com.urbanshield.app.ui.TabNavigator
import com.urbanshield.app.ui.ZonesFragment

/**
 * Pantalla principal de la app una vez que el usuario ya inició sesión (o entró
 * como invitado) y ya se pidieron los permisos. Aloja las 5 pestañas de la barra
 * de navegación inferior (Inicio, Mapa, Alertas, Zonas, Perfil) como fragments,
 * manteniéndolos todos vivos en memoria (add + hide/show) para no perder el
 * estado del mapa o de las listas cada vez que el usuario cambia de pestaña.
 */
class HomeActivity : AppCompatActivity(), TabNavigator {

    private lateinit var binding: ActivityHomeBinding

    private val homeFragment = HomeFragment()
    private val mapFragment = MapFragment()
    private val alertsFragment = AlertsFragment()
    private val zonesFragment = ZonesFragment()
    private val profileFragment = ProfileFragment()
    private var activeFragment: Fragment = homeFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, profileFragment, TAG_PROFILE).hide(profileFragment)
                .add(R.id.fragmentContainer, zonesFragment, TAG_ZONES).hide(zonesFragment)
                .add(R.id.fragmentContainer, alertsFragment, TAG_ALERTS).hide(alertsFragment)
                .add(R.id.fragmentContainer, mapFragment, TAG_MAP).hide(mapFragment)
                .add(R.id.fragmentContainer, homeFragment, TAG_HOME)
                .commit()
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            val target = fragmentForItemId(item.itemId)
            switchTo(target)
            true
        }
    }

    private fun fragmentForItemId(itemId: Int): Fragment = when (itemId) {
        R.id.nav_home -> homeFragment
        R.id.nav_map -> mapFragment
        R.id.nav_alerts -> alertsFragment
        R.id.nav_zones -> zonesFragment
        R.id.nav_profile -> profileFragment
        else -> homeFragment
    }

    private fun switchTo(fragment: Fragment) {
        if (fragment === activeFragment) return
        supportFragmentManager.beginTransaction()
            .hide(activeFragment)
            .show(fragment)
            .commit()
        activeFragment = fragment
    }

    override fun navigateToTab(itemId: Int) {
        binding.bottomNavigation.selectedItemId = itemId
    }

    companion object {
        private const val TAG_HOME = "tab_home"
        private const val TAG_MAP = "tab_map"
        private const val TAG_ALERTS = "tab_alerts"
        private const val TAG_ZONES = "tab_zones"
        private const val TAG_PROFILE = "tab_profile"
    }
}
