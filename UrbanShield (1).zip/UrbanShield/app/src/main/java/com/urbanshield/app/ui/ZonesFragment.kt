package com.urbanshield.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.urbanshield.app.R
import com.urbanshield.app.data.RiskZoneRepository
import com.urbanshield.app.databinding.FragmentZonesBinding
import kotlinx.coroutines.launch

/** Pestaña "Zonas": lista completa de las zonas de riesgo en CDMX y Edomex. */
class ZonesFragment : Fragment() {

    private var _binding: FragmentZonesBinding? = null
    private val binding get() = _binding!!
    private val repository = RiskZoneRepository()
    private lateinit var adapter: ZonesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentZonesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = ZonesAdapter(emptyList())
        binding.recyclerZones.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerZones.adapter = adapter
        loadZones()
    }

    private fun loadZones() {
        binding.progressZones.visibility = View.VISIBLE
        viewLifecycleOwner.lifecycleScope.launch {
            val zones = repository.getRiskZones()
            if (_binding == null) return@launch
            adapter.submitList(zones)
            binding.textZonesSubtitle.text = getString(R.string.zones_subtitle_count, zones.size)
            binding.progressZones.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
