# Reglas de ProGuard específicas del proyecto UrbanShield.
# Vacío por ahora; se usa la configuración por defecto de Android.
