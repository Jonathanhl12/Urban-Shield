# UrbanShield — App de alertas de inseguridad

Prototipo funcional en Android (Kotlin) que muestra zonas de riesgo reales de
la Ciudad de México y el Estado de México en un mapa, y envía notificaciones
cuando el usuario entra o se acerca a una de ellas. La interfaz sigue la guía
de estilo del proyecto (paleta de colores, tipografía y componentes de
Material Design 3 definidos en el Portafolio de evidencias U2).

## Qué incluye este proyecto

- **Pantalla de bienvenida** con el logo real de UrbanShield, login / registro
  (Firebase Authentication) y acceso como invitado (`WelcomeActivity`).
- **Paso de permisos invisible** (sin pantalla dedicada): `MainActivity`
  solicita ubicación y notificaciones automáticamente y pasa directo a la app.
- **Navegación principal con 5 pestañas** (`HomeActivity` + barra de
  navegación inferior):
  1. **Inicio** — saludo, estadísticas rápidas y accesos directos (`ui/HomeFragment.kt`)
  2. **Mapa** — mapa interactivo con las 16 zonas de riesgo y geofencing (`ui/MapFragment.kt`)
  3. **Alertas** — historial local de notificaciones recibidas (`ui/AlertsFragment.kt`)
  4. **Zonas** — listado completo de zonas de riesgo con su nivel (`ui/ZonesFragment.kt`)
  5. **Perfil** — estado de la sesión, preferencia de alertas y cerrar sesión (`ui/ProfileFragment.kt`)
- Geolocalización en tiempo real (Fused Location Provider) y geofencing.
- Notificaciones push locales que además quedan guardadas en el historial de
  la pestaña "Alertas".
- Repositorio conectado a Firebase Firestore con 16 zonas reales de
  respaldo local (CDMX y Edomex) si Firestore aún está vacío.
- Ícono de la app y logo de bienvenida con tu diseño real (escudo + pin).

## Guía de estilo aplicada

| Elemento | Valor |
|---|---|
| Color principal | `#1565C0` |
| Color de barra/oscuro | `#0D47A1` |
| Fondo | `#FFFFFF` |
| Tarjetas | `#F5F5F5` |
| Alertas / riesgo alto | `#E53935` |
| Riesgo medio | `#FB8C00` |
| Riesgo bajo | `#FBC02D` (amarillo — no verde, ese color está reservado para "Confirmaciones") |
| Confirmaciones | `#4CAF50` |
| Tipografía | Roboto (fuente por defecto de Android) |
| Títulos / subtítulos / texto / botones / notas | 32 / 24 / 16 / 14 / 12 sp |

Los chips de nivel de riesgo usan texto **negro**, no blanco: se verificó con
la fórmula de contraste WCAG que el blanco no pasa el mínimo 4.5:1 exigido
por la guía de accesibilidad contra ninguno de los 3 colores de riesgo.

## Requisitos previos

1. **Android Studio** (versión Hedgehog / 2023.1 o más reciente).
2. **JDK 17** — Android Studio moderno ya lo trae integrado.
3. Una cuenta de Google (para Firebase y Google Cloud Console).
4. Un dispositivo Android físico con GPS, o un emulador con Google Play Services.

## Paso 1 — Abrir el proyecto

1. Descomprime este proyecto.
2. Abre Android Studio → `File > Open` → selecciona la carpeta `UrbanShield`.
3. Espera el "Gradle Sync". Si te pregunta si quieres crear el Gradle
   Wrapper, acepta.

## Paso 2 — Firebase (base de datos + login)

1. Ve a https://console.firebase.google.com y crea un proyecto.
2. Agrega una app Android con el paquete exacto: `com.urbanshield.app`
3. Descarga `google-services.json` y ponlo en la carpeta `app/` (reemplaza
   el `.example`).
4. **Firestore Database** → crear base de datos en modo de prueba.
5. **Authentication** → "Sign-in method" → habilita **Correo electrónico y
   contraseña**. Sin esto, el login falla (pero "Continuar sin cuenta" sigue
   funcionando).
6. (Opcional) Sube tus propias zonas a la colección `risk_zones`. Si no
   agregas nada, se usan las 16 zonas reales de CDMX/Edomex ya incluidas.

## Paso 3 — Clave de Google Maps

1. https://console.cloud.google.com/ → mismo proyecto que Firebase.
2. Habilita **"Maps SDK for Android"**.
3. Crea una clave de API en **Credenciales**.
4. Pégala en `app/src/main/res/values/strings.xml`, reemplazando
   `TU_CLAVE_DE_GOOGLE_MAPS_AQUI`.

## Paso 4 — Ejecutar

Conecta un dispositivo o abre un emulador con Google Play, dale ▶ Run. Verás
la bienvenida con el logo, después la app pide permisos sola y entra directo
a "Inicio". Para simular ubicación en el emulador: Extended controls →
Location → prueba con `19.4326, -99.1332` (Centro Histórico CDMX).

## Estructura del proyecto

```
UrbanShield/
├── app/
│   ├── build.gradle
│   ├── google-services.json.example
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/urbanshield/app/
│       │   ├── UrbanShieldApp.kt
│       │   ├── WelcomeActivity.kt        # Login / registro / invitado
│       │   ├── MainActivity.kt           # Paso invisible de permisos
│       │   ├── HomeActivity.kt           # Contenedor de las 5 pestañas
│       │   ├── ui/                       # Los 5 fragments + sus adaptadores
│       │   ├── data/                     # Modelos + Firestore + historial local
│       │   ├── geofence/                 # Geofencing
│       │   └── notifications/            # Alertas
│       └── res/
│           ├── layout/    # Todas las pantallas y pestañas
│           ├── menu/      # Barra de navegación inferior
│           ├── values/    # strings, colores (paleta oficial), tema
│           ├── color/     # Selector de color de la barra de navegación
│           └── drawable, mipmap/  # Íconos, logo, launcher
├── build.gradle
└── settings.gradle
```

## Problemas comunes

- **El mapa se ve gris:** clave de Maps inválida o "Maps SDK for Android" no habilitado.
- **No llegan notificaciones:** revisa el permiso de ubicación en segundo plano.
- **Firestore no carga datos:** confirma que copiaste tu `google-services.json` real.
- **Error al iniciar sesión:** activa "Correo electrónico y contraseña" en Authentication.
